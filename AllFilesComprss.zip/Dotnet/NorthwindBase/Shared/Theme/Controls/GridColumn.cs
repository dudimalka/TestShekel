﻿namespace Northwind.Shared.Theme.Controls
{
    public partial class GridColumn : ENV.UI.GridColumn 
    {
        /// <summary>GridColumn</summary>
        public GridColumn()
        {
            InitializeComponent();
        }
    }
}
