﻿namespace Northwind.Shared.Theme.Controls
{
    partial class SubForm
    {
        void InitializeComponent()
        {
            AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0,0,0,0);
        }
    }
}
