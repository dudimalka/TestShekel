﻿namespace Northwind.Shared.Theme.Controls
{
    public partial class TreeView : ENV.UI.TreeView 
    {
        /// <summary>TreeView</summary>
        public TreeView()
        {
            InitializeComponent();
        }
    }
}
