﻿namespace Northwind.Shared.Theme.Controls
{
    public partial class CompatibleForm : Form 
    {
        /// <summary>CompatibleForm</summary>
        public CompatibleForm()
        {
            InitializeComponent();
        }
    }
}
