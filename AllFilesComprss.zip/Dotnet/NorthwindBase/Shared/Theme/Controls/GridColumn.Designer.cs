﻿namespace Northwind.Shared.Theme.Controls
{
    partial class GridColumn
    {
        void InitializeComponent()
        {
            Alignment = System.Drawing.ContentAlignment.MiddleLeft;
            RightToLeftLayout = false;
        }
    }
}
