﻿namespace Northwind.Shared.Theme.Controls
{
    public partial class RadioButton : ENV.UI.RadioButton 
    {
        /// <summary>RadioButton</summary>
        public RadioButton()
        {
            InitializeComponent();
        }
    }
}
