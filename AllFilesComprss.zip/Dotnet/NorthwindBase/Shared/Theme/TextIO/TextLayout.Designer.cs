﻿namespace Northwind.Shared.Theme.TextIO
{
    partial class TextLayout
    {
        void InitializeComponent()
        {
            FontScheme = new Northwind.Shared.Theme.Fonts.DefaultFixedSizeFont();
        }
    }
}
