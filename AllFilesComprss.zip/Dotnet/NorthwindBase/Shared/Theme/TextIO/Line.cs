﻿namespace Northwind.Shared.Theme.TextIO
{
    public class Line : ENV.IO.Line 
    {
        /// <summary>Line</summary>
        public Line()
        {
            InitializeComponent();
        }
        void InitializeComponent()
        {
        }
    }
}
