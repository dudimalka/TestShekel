﻿namespace Northwind.Shared.Theme.TextIO
{
    public class Shape : ENV.IO.Shape 
    {
        /// <summary>Shape</summary>
        public Shape()
        {
            InitializeComponent();
        }
        void InitializeComponent()
        {
        }
    }
}
