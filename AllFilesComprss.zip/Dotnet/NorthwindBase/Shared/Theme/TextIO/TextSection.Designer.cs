﻿namespace Northwind.Shared.Theme.TextIO
{
    partial class TextSection
    {
        void InitializeComponent()
        {
            WidthInChars = 40;
            HeightInChars = 18;
        }
    }
}
