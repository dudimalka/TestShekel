﻿namespace Northwind.Shared.Theme.Printing
{
    public partial class GridColumn : ENV.Printing.GridColumn 
    {
        /// <summary>GridColumn</summary>
        public GridColumn()
        {
            InitializeComponent();
        }
    }
}
