﻿namespace Northwind.Shared.Theme.Printing
{
    public partial class RichTextBox : ENV.Printing.RichTextBox 
    {
        /// <summary>RichTextBox</summary>
        public RichTextBox()
        {
            InitializeComponent();
        }
    }
}
