﻿namespace Northwind.Shared.Theme.Printing
{
    partial class ReportLayout
    {
        void InitializeComponent()
        {
        }
    }
}
