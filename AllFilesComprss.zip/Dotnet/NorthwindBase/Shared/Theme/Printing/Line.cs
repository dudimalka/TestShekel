﻿namespace Northwind.Shared.Theme.Printing
{
    public partial class Line : Firefly.Box.UI.Line 
    {
        /// <summary>Line</summary>
        public Line()
        {
            InitializeComponent();
        }
    }
}
