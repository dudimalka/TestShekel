﻿namespace Northwind.Shared.Theme.Printing
{
    public partial class PictureBox : ENV.Printing.PictureBox 
    {
        /// <summary>PictureBox</summary>
        public PictureBox()
        {
            InitializeComponent();
        }
    }
}
