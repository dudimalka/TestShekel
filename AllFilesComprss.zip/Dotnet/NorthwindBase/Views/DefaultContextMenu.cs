﻿using ENV.UI.Menus;
using Firefly.Box;
namespace Northwind.Views
{
    public class DefaultContextMenu : ContextMenuStripBase 
    {
        public DefaultContextMenu(System.ComponentModel.IContainer container) : base(container)
        {
        }
    }
}
