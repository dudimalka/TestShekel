﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace Northwind.Views.Controls
{
    /// <summary>V9 Compatible Default Table(M#8)</summary>
    [System.ComponentModel.Description("V9 Compatible Default Table")]
    public partial class V9CompatibleDefaultTable : Shared.Theme.Controls.CompatibleGrid 
    {
        public V9CompatibleDefaultTable()
        {
            InitializeComponent();
        }
    }
}
