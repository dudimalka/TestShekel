﻿using ENV;
namespace Northwind.Products
{
    /// <summary>Show Products(P#4)</summary>
    public interface IShowProducts
    {
        /// <summary>Show Products(P#4)</summary>
        void Run(NumberParameter ppi_ProdID = null);
    }
}
