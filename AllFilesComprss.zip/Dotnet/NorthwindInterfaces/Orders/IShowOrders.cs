﻿using ENV;
namespace Northwind.Orders
{
    /// <summary>Show Orders(P#5)</summary>
    public interface IShowOrders
    {
        /// <summary>Show Orders(P#5)</summary>
        void Run();
    }
}
