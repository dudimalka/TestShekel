﻿using ENV;
namespace Northwind.Customers
{
    /// <summary>Show Customers(P#3)</summary>
    public interface IShowCustomers
    {
        /// <summary>Show Customers(P#3)</summary>
        void Run(TextParameter ppi_CustomerID = null);
    }
}
