﻿namespace Northwind.Views.Views
{
    partial class ShowTestView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grid1 = new Northwind.Shared.Theme.Controls.Grid();
            this.gcProductID = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtProductID = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcProductName = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtProductName = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcSupplierID = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtSupplierID = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcCategoryID = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtCategoryID = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcQuantityPerUnit = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtQuantityPerUnit = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcUnitPrice = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtUnitPrice = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcUnitsInStock = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtUnitsInStock = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcUnitsOnOrder = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtUnitsOnOrder = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcReorderLevel = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtReorderLevel = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.gcDiscontinued = new Northwind.Shared.Theme.Controls.CompatibleGridColumn();
            this.txtDiscontinued = new Northwind.Shared.Theme.Controls.CompatibleTextBox();
            this.grid1.SuspendLayout();
            this.gcProductID.SuspendLayout();
            this.gcProductName.SuspendLayout();
            this.gcSupplierID.SuspendLayout();
            this.gcCategoryID.SuspendLayout();
            this.gcQuantityPerUnit.SuspendLayout();
            this.gcUnitPrice.SuspendLayout();
            this.gcUnitsInStock.SuspendLayout();
            this.gcUnitsOnOrder.SuspendLayout();
            this.gcReorderLevel.SuspendLayout();
            this.gcDiscontinued.SuspendLayout();
            this.SuspendLayout();
            // 
            // grid1
            // 
            this.grid1.Controls.Add(this.gcProductID);
            this.grid1.Controls.Add(this.gcProductName);
            this.grid1.Controls.Add(this.gcSupplierID);
            this.grid1.Controls.Add(this.gcCategoryID);
            this.grid1.Controls.Add(this.gcQuantityPerUnit);
            this.grid1.Controls.Add(this.gcUnitPrice);
            this.grid1.Controls.Add(this.gcUnitsInStock);
            this.grid1.Controls.Add(this.gcUnitsOnOrder);
            this.grid1.Controls.Add(this.gcReorderLevel);
            this.grid1.Controls.Add(this.gcDiscontinued);
            this.grid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid1.Location = new System.Drawing.Point(0, 0);
            this.grid1.Name = "grid1";
            this.grid1.Size = new System.Drawing.Size(2290, 972);
            this.grid1.Text = "grid1";
            // 
            // gcProductID
            // 
            this.gcProductID.Controls.Add(this.txtProductID);
            this.gcProductID.Name = "gcProductID";
            this.gcProductID.Text = "ProductID";
            this.gcProductID.Width = 197;
            // 
            // txtProductID
            // 
            this.txtProductID.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtProductID.Location = new System.Drawing.Point(2, 1);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(191, 30);
            this.txtProductID.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtProductID.Data = this._controller.products.ProductID;
            // 
            // gcProductName
            // 
            this.gcProductName.Controls.Add(this.txtProductName);
            this.gcProductName.Name = "gcProductName";
            this.gcProductName.Text = "ProductName";
            this.gcProductName.Width = 435;
            // 
            // txtProductName
            // 
            this.txtProductName.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtProductName.Location = new System.Drawing.Point(2, 1);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(429, 30);
            this.txtProductName.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtProductName.Data = this._controller.products.ProductName;
            // 
            // gcSupplierID
            // 
            this.gcSupplierID.Controls.Add(this.txtSupplierID);
            this.gcSupplierID.Name = "gcSupplierID";
            this.gcSupplierID.Text = "SupplierID";
            this.gcSupplierID.Width = 197;
            // 
            // txtSupplierID
            // 
            this.txtSupplierID.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtSupplierID.Location = new System.Drawing.Point(2, 1);
            this.txtSupplierID.Name = "txtSupplierID";
            this.txtSupplierID.Size = new System.Drawing.Size(191, 30);
            this.txtSupplierID.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtSupplierID.Data = this._controller.products.SupplierID;
            // 
            // gcCategoryID
            // 
            this.gcCategoryID.Controls.Add(this.txtCategoryID);
            this.gcCategoryID.Name = "gcCategoryID";
            this.gcCategoryID.Text = "CategoryID";
            this.gcCategoryID.Width = 197;
            // 
            // txtCategoryID
            // 
            this.txtCategoryID.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtCategoryID.Location = new System.Drawing.Point(2, 1);
            this.txtCategoryID.Name = "txtCategoryID";
            this.txtCategoryID.Size = new System.Drawing.Size(191, 30);
            this.txtCategoryID.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtCategoryID.Data = this._controller.products.CategoryID;
            // 
            // gcQuantityPerUnit
            // 
            this.gcQuantityPerUnit.Controls.Add(this.txtQuantityPerUnit);
            this.gcQuantityPerUnit.Name = "gcQuantityPerUnit";
            this.gcQuantityPerUnit.Text = "QuantityPerUnit";
            this.gcQuantityPerUnit.Width = 350;
            // 
            // txtQuantityPerUnit
            // 
            this.txtQuantityPerUnit.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtQuantityPerUnit.Location = new System.Drawing.Point(2, 1);
            this.txtQuantityPerUnit.Name = "txtQuantityPerUnit";
            this.txtQuantityPerUnit.Size = new System.Drawing.Size(344, 30);
            this.txtQuantityPerUnit.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtQuantityPerUnit.Data = this._controller.products.QuantityPerUnit;
            // 
            // gcUnitPrice
            // 
            this.gcUnitPrice.Controls.Add(this.txtUnitPrice);
            this.gcUnitPrice.Name = "gcUnitPrice";
            this.gcUnitPrice.Text = "UnitPrice";
            this.gcUnitPrice.Width = 248;
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtUnitPrice.Location = new System.Drawing.Point(2, 1);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(242, 30);
            this.txtUnitPrice.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtUnitPrice.Data = this._controller.products.UnitPrice;
            // 
            // gcUnitsInStock
            // 
            this.gcUnitsInStock.Controls.Add(this.txtUnitsInStock);
            this.gcUnitsInStock.Name = "gcUnitsInStock";
            this.gcUnitsInStock.Text = "UnitsInStock";
            this.gcUnitsInStock.Width = 118;
            // 
            // txtUnitsInStock
            // 
            this.txtUnitsInStock.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtUnitsInStock.Location = new System.Drawing.Point(2, 1);
            this.txtUnitsInStock.Name = "txtUnitsInStock";
            this.txtUnitsInStock.Size = new System.Drawing.Size(106, 30);
            this.txtUnitsInStock.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtUnitsInStock.Data = this._controller.products.UnitsInStock;
            // 
            // gcUnitsOnOrder
            // 
            this.gcUnitsOnOrder.Controls.Add(this.txtUnitsOnOrder);
            this.gcUnitsOnOrder.Name = "gcUnitsOnOrder";
            this.gcUnitsOnOrder.Text = "UnitsOnOrder";
            this.gcUnitsOnOrder.Width = 129;
            // 
            // txtUnitsOnOrder
            // 
            this.txtUnitsOnOrder.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtUnitsOnOrder.Location = new System.Drawing.Point(2, 1);
            this.txtUnitsOnOrder.Name = "txtUnitsOnOrder";
            this.txtUnitsOnOrder.Size = new System.Drawing.Size(106, 30);
            this.txtUnitsOnOrder.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtUnitsOnOrder.Data = this._controller.products.UnitsOnOrder;
            // 
            // gcReorderLevel
            // 
            this.gcReorderLevel.Controls.Add(this.txtReorderLevel);
            this.gcReorderLevel.Name = "gcReorderLevel";
            this.gcReorderLevel.Text = "ReorderLevel";
            this.gcReorderLevel.Width = 124;
            // 
            // txtReorderLevel
            // 
            this.txtReorderLevel.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtReorderLevel.Location = new System.Drawing.Point(2, 1);
            this.txtReorderLevel.Name = "txtReorderLevel";
            this.txtReorderLevel.Size = new System.Drawing.Size(106, 30);
            this.txtReorderLevel.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtReorderLevel.Data = this._controller.products.ReorderLevel;
            // 
            // gcDiscontinued
            // 
            this.gcDiscontinued.Controls.Add(this.txtDiscontinued);
            this.gcDiscontinued.Name = "gcDiscontinued";
            this.gcDiscontinued.Text = "Discontinued";
            this.gcDiscontinued.Width = 121;
            // 
            // txtDiscontinued
            // 
            this.txtDiscontinued.AdvancedAnchor = new Firefly.Box.UI.AdvancedAnchor(0, 100, 0, 100);
            this.txtDiscontinued.Location = new System.Drawing.Point(2, 1);
            this.txtDiscontinued.Name = "txtDiscontinued";
            this.txtDiscontinued.Size = new System.Drawing.Size(89, 30);
            this.txtDiscontinued.Style = Firefly.Box.UI.ControlStyle.Flat;
            this.txtDiscontinued.Data = this._controller.products.Discontinued;
            // 
            // ShowTestView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2290, 972);
            this.Controls.Add(this.grid1);
            this.HorizontalExpressionFactor = 1D;
            this.Name = "ShowTestView";
            this.Text = "Test";
            this.VerticalExpressionFactor = 1D;
            this.Load += new System.EventHandler(this.ShowTestView_Load);
            this.grid1.ResumeLayout(false);
            this.gcProductID.ResumeLayout(false);
            this.gcProductName.ResumeLayout(false);
            this.gcSupplierID.ResumeLayout(false);
            this.gcCategoryID.ResumeLayout(false);
            this.gcQuantityPerUnit.ResumeLayout(false);
            this.gcUnitPrice.ResumeLayout(false);
            this.gcUnitsInStock.ResumeLayout(false);
            this.gcUnitsOnOrder.ResumeLayout(false);
            this.gcReorderLevel.ResumeLayout(false);
            this.gcDiscontinued.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Shared.Theme.Controls.CompatibleGridColumn gcProductID;
        private Shared.Theme.Controls.CompatibleTextBox txtProductID;
        private Shared.Theme.Controls.CompatibleGridColumn gcProductName;
        private Shared.Theme.Controls.CompatibleTextBox txtProductName;
        private Shared.Theme.Controls.CompatibleGridColumn gcSupplierID;
        private Shared.Theme.Controls.CompatibleTextBox txtSupplierID;
        private Shared.Theme.Controls.CompatibleGridColumn gcCategoryID;
        private Shared.Theme.Controls.CompatibleTextBox txtCategoryID;
        private Shared.Theme.Controls.CompatibleGridColumn gcQuantityPerUnit;
        private Shared.Theme.Controls.CompatibleTextBox txtQuantityPerUnit;
        private Shared.Theme.Controls.CompatibleGridColumn gcUnitPrice;
        private Shared.Theme.Controls.CompatibleTextBox txtUnitPrice;
        private Shared.Theme.Controls.CompatibleGridColumn gcUnitsInStock;
        private Shared.Theme.Controls.CompatibleTextBox txtUnitsInStock;
        private Shared.Theme.Controls.CompatibleGridColumn gcUnitsOnOrder;
        private Shared.Theme.Controls.CompatibleTextBox txtUnitsOnOrder;
        private Shared.Theme.Controls.CompatibleGridColumn gcReorderLevel;
        private Shared.Theme.Controls.CompatibleTextBox txtReorderLevel;
        private Shared.Theme.Controls.CompatibleGridColumn gcDiscontinued;
        private Shared.Theme.Controls.CompatibleTextBox txtDiscontinued;
        private Shared.Theme.Controls.Grid grid1;
    }
}