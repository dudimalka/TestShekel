﻿using ENV;
using ENV.Data;
using Firefly.Box;
using Firefly.Box.UI.Advanced;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Northwind.Views.Views
{
    partial class ShowTestView : Shared.Theme.Controls.Form
    {
        ShowTest _controller;
        public ShowTestView(ShowTest controller)
        {
            _controller = controller;
            InitializeComponent();
        }

        private void ShowTestView_Load(object sender, EventArgs e)
        {

        }

        private void grid1_Click(object sender, EventArgs e)
        {

        }
    }
}