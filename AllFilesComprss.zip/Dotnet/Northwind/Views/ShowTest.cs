﻿using ENV;
using ENV.Data;
using Firefly.Box;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace Northwind.Views
{
    public class ShowTest : UIControllerBase
    {
        public readonly Models.Products products = new Models.Products();
        public ShowTest()
        {
            From = products;
            Where.Add(products.ProductName.StartsWith('C'));
        }

        public void Run()
        {
            Execute();
        }

        protected override void OnLoad()
        {
            View = () => new Views.ShowTestView(this);
        }
    }
}