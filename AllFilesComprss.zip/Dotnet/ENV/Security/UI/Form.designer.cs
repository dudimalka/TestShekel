﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{
    partial class Form
    {
        void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form
            // 
            this.AllowDrop = false;
            this.ClientSize = new System.Drawing.Size(492, 370);
            this.Name = "Form";
            this.StartPosition = Firefly.Box.UI.WindowStartPosition.CenterMDI;
            this.ResumeLayout(false);

        }
    }
}
