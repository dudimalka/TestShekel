﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{

    /// <summary>GridColumn</summary>
    public partial class GridColumn : Firefly.Box.UI.GridColumn
    {


        /// <summary>GridColumn</summary>
        public GridColumn()
        {
            InitializeComponent();
        }

    }
}
