﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{

    /// <summary>Button</summary>
    public partial class Button : Firefly.Box.UI.Button
    {


        /// <summary>Button</summary>
        public Button()
        {
            InitializeComponent();
        }

    }
}
