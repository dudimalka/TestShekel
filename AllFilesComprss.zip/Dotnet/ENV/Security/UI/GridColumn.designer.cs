﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{
    partial class GridColumn
    {
        void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // GridColumn
            // 
    //        this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Location = new System.Drawing.Point(0, 0);
            this.ResumeLayout(false);

        }
    }
}
