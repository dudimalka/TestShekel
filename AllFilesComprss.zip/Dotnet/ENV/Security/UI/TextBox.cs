﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{

    /// <summary>TextBox</summary>
    public partial class TextBox : Firefly.Box.UI.TextBox
    {


        /// <summary>TextBox</summary>
        public TextBox()
        {
            InitializeComponent();
        }

    }
}
