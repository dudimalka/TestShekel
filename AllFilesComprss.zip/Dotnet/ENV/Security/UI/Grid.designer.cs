﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{
    partial class Grid
    {
        void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Grid
            // 
            this.Location = new System.Drawing.Point(0, 0);
            this.RowHeight = 22;
            DrawPartialRow = false;
            this.ResumeLayout(false);

        }
    }
}
