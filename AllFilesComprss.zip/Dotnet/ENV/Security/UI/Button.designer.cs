﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Security.UI
{
    partial class Button
    {
        void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Button
            // 
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Location = new System.Drawing.Point(0, 0);
            this.RightToLeftLayout = false;
            this.ResumeLayout(false);

        }
    }
}
