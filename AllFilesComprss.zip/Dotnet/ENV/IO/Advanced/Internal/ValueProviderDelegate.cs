﻿namespace ENV.IO.Advanced.Internal
{
    delegate string ValueProviderDelegate(bool rightToLeft);
}