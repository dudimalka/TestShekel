﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ENV.IO.Advanced;

namespace ENV.IO
{
    public class DummyForm
    {
        public void WriteTo(Writer writer)
        {
        }
    }
}
