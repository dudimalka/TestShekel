﻿using Firefly.Box;

namespace ENV
{
    
    public class UIControllerBase : AbstractUIController
    {
        internal override void _doOnAdvancedSettings(UIController.AdvancedSettings settings)
        {
            
        }

        
        
    }
}
