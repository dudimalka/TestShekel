﻿using System.Drawing;
using Firefly.Box.UI;
using Firefly.Box;
namespace ENV.Labs.UI
{
    partial class ScreenPicture
    {
        void InitializeComponent()
        {
        }
    }
}
