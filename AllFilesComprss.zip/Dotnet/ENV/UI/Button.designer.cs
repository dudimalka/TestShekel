﻿namespace ENV.UI
{
    partial class Button
    {
        void InitializeComponent()
        {
           
        }
    }
}
