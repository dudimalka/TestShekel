﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ENV.UI
{
    public class ActiveX:Firefly.Box.Interop.UI.ActiveX
    {
    }
}
