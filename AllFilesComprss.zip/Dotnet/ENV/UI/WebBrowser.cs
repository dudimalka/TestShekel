﻿using System;

namespace ENV.UI
{
    public class WebBrowser : Firefly.Box.UI.WebBrowser
    {
    }
}
